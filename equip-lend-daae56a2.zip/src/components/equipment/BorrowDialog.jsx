
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar, Package } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function BorrowDialog({ equipments, isOpen, onClose, onSubmit, user }) {
  const [expectedReturnDate, setExpectedReturnDate] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!expectedReturnDate) return;
    setIsSubmitting(true);
    
    try {
      await onSubmit(expectedReturnDate);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!equipments || equipments.length === 0) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-slate-900">
            Confirm Borrow Request
          </DialogTitle>
          <div className="text-sm text-slate-600">
            You are requesting to borrow {equipments.length} item(s).
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-60 mt-4 pr-4">
          <div className="space-y-3">
            {equipments.map(item => (
              <div key={item.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                <Package className="w-5 h-5 text-blue-600" />
                <div className="flex-1">
                  <p className="font-medium text-slate-800">{item.name}</p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        
        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="space-y-2">
            <Label htmlFor="return_date" className="text-sm font-medium text-slate-700">
              Expected return date for all items *
            </Label>
            <div className="relative">
              <Input
                id="return_date"
                type="date"
                value={expectedReturnDate}
                onChange={(e) => setExpectedReturnDate(e.target.value)}
                required
                min={new Date().toISOString().split('T')[0]}
                className="border-slate-200 focus:border-blue-400 focus:ring-blue-400"
              />
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            </div>
          </div>
          
          <div className="flex gap-3 pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !expectedReturnDate}
              className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              {isSubmitting ? "Submitting..." : `Submit Request for ${equipments.length} Items`}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
