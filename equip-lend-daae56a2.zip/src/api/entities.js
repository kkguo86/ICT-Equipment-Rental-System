import { base44 } from './base44Client';


export const Equipment = base44.entities.Equipment;

export const BorrowRequest = base44.entities.BorrowRequest;



// auth sdk:
export const User = base44.auth;