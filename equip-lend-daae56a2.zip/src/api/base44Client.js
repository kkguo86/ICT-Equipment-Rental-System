import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "6891c95e27bbbef4daae56a2", 
  requiresAuth: true // Ensure authentication is required for all operations
});
