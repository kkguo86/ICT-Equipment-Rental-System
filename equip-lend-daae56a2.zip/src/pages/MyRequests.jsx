import React, { useState, useEffect } from "react";
import { BorrowRequest } from "@/api/entities";
import { Equipment } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, CheckCircle, Package, Calendar, User as UserIcon } from "lucide-react";
import { format } from "date-fns";

export default function MyRequestsPage() {
  const [requests, setRequests] = useState([]);
  const [equipment, setEquipment] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      
      const [requestsData, equipmentData] = await Promise.all([
        BorrowRequest.filter({ borrower_email: userData.email }, '-created_date'),
        Equipment.list()
      ]);
      
      setRequests(requestsData);
      setEquipment(equipmentData);
    } catch (error) {
      console.error("Error loading requests:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">Please sign in</h1>
          <p className="text-slate-600">You need to be signed in to view your requests.</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'approved':
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'returned':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'overdue':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'approved':
      case 'active':
        return <CheckCircle className="w-4 h-4" />;
      case 'returned':
        return <Package className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const pendingRequests = requests.filter(r => r.status === 'pending');
  const activeRequests = requests.filter(r => r.status === 'active');
  const completedRequests = requests.filter(r => ['returned', 'cancelled'].includes(r.status));

  const RequestCard = ({ request }) => {
    const equipmentItem = equipment.find(e => e.id === request.equipment_id);
    
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold text-slate-900">
                  {equipmentItem?.name || 'Unknown Equipment'}
                </CardTitle>
                <p className="text-sm text-slate-500">
                  {equipmentItem?.model && `${equipmentItem.model} • `}
                  Serial: {equipmentItem?.serial_number}
                </p>
              </div>
            </div>
            <Badge className={`${getStatusColor(request.status)} border font-medium flex items-center gap-1`}>
              {getStatusIcon(request.status)}
              {request.status === 'active' ? 'Borrowed' : request.status}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-slate-600 flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                Requested:
              </span>
              <p className="font-medium text-slate-900 mt-1">
                {format(new Date(request.created_date), 'PPP')}
              </p>
            </div>
            <div>
              <span className="text-slate-600 flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                Expected Return:
              </span>
              <p className="font-medium text-slate-900 mt-1">
                {format(new Date(request.expected_return_date), 'PPP')}
              </p>
            </div>
            {request.approved_by && (
              <div>
                <span className="text-slate-600 flex items-center gap-1">
                  <UserIcon className="w-4 h-4" />
                  Approved by:
                </span>
                <p className="font-medium text-slate-900 mt-1">{request.approved_by}</p>
              </div>
            )}
            {request.actual_return_date && (
              <div>
                <span className="text-slate-600 flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Returned:
                </span>
                <p className="font-medium text-slate-900 mt-1">
                  {format(new Date(request.actual_return_date), 'PPP')}
                </p>
              </div>
            )}
          </div>

          {request.return_notes && (
            <div className="bg-slate-50 p-3 rounded-lg">
              <span className="text-slate-600 text-sm">Return Notes:</span>
              <p className="text-slate-900 text-sm mt-1">{request.return_notes}</p>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-blue-700 bg-clip-text text-transparent mb-3">
            My Equipment Requests
          </h1>
          <p className="text-slate-600 text-lg">
            Track your equipment borrowing history and current requests
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Pending Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-600">{pendingRequests.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Active Equipment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{activeRequests.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-slate-200/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
                <Package className="w-4 h-4" />
                Total Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{requests.length}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="bg-white/80 backdrop-blur-sm p-1 rounded-xl border border-slate-200/60">
            <TabsTrigger value="pending" className="data-[state=active]:bg-amber-600 data-[state=active]:text-white">
              Pending ({pendingRequests.length})
            </TabsTrigger>
            <TabsTrigger value="active" className="data-[state=active]:bg-green-600 data-[state=active]:text-white">
              Active Equipment ({activeRequests.length})
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              Completed ({completedRequests.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4">
            {isLoading ? (
              <div className="grid gap-4">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="bg-white rounded-xl p-6 animate-pulse">
                    <div className="h-6 bg-slate-200 rounded mb-3"></div>
                    <div className="h-4 bg-slate-200 rounded mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  </div>
                ))}
              </div>
            ) : pendingRequests.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No pending requests</h3>
                <p className="text-slate-600">Your pending requests will appear here</p>
              </div>
            ) : (
              pendingRequests.map((request) => (
                <RequestCard key={request.id} request={request} />
              ))
            )}
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            {isLoading ? (
              <div className="grid gap-4">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="bg-white rounded-xl p-6 animate-pulse">
                    <div className="h-6 bg-slate-200 rounded mb-3"></div>
                    <div className="h-4 bg-slate-200 rounded mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  </div>
                ))}
              </div>
            ) : activeRequests.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No active equipment</h3>
                <p className="text-slate-600">Your borrowed equipment will appear here</p>
              </div>
            ) : (
              activeRequests.map((request) => (
                <RequestCard key={request.id} request={request} />
              ))
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {isLoading ? (
              <div className="grid gap-4">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="bg-white rounded-xl p-6 animate-pulse">
                    <div className="h-6 bg-slate-200 rounded mb-3"></div>
                    <div className="h-4 bg-slate-200 rounded mb-2"></div>
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  </div>
                ))}
              </div>
            ) : completedRequests.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-slate-900 mb-2">No completed requests</h3>
                <p className="text-slate-600">Your request history will appear here</p>
              </div>
            ) : (
              completedRequests.map((request) => (
                <RequestCard key={request.id} request={request} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}